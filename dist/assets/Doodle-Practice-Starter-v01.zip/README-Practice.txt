Doodle animation practice: one focused revision

This is an independent editable copy of Henry's cat-and-fish opening.
The original fish is blue (#71b7be). This revision changes only its fill to pink (#d996a4).
The character, motion, timing, greeting and source audio are otherwise identical.

Try one change
1. Open settings.json and change fishColor to another six-digit hex color.
2. Run: node build.mjs
3. With HyperFrames available, open the preview: npm run dev
4. Watch the result and verify that only the intended color changed.
5. Keep the editable source and a working preview before the next revision.

Requirements
Node.js 22 or newer, FFmpeg, and an available HyperFrames CLI workflow.
The project uses the pinned CLI version in package.json. Initial package retrieval may need network access.
No OpenAI API key, paid image model or external video generator is used by this project.

Files
settings.json: one editable fishColor value.
build.mjs: regenerates index.html, the SVG scene and the original-doodle.svg asset.
compositions/doodle.html: editable generated animation scene.
assets/: local GSAP, fonts, drawing and temporary voice/sound files.
narration.json / voice-timing.json: English review narration and measured timing.
Practice-Cat-Pink-v01.mp4: exported example, when included.

Example request for Codex
Change only the fish from blue to pink. Keep the cat, movement and timing unchanged.
Keep the source editable. Check the preview and export a local MP4.

This is a practice project, with Microsoft Zira Desktop as temporary review narration.
