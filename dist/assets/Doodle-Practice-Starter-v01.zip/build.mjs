import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const settings=JSON.parse(fs.readFileSync(path.join(dir,'settings.json'),'utf8').replace(/^\uFEFF/,''));
const voice=JSON.parse(fs.readFileSync(path.join(dir,'voice-timing.json'),'utf8').replace(/^\uFEFF/,''));
const end=Math.ceil((voice.at(-1).start+voice.at(-1).duration+1.2)*30)/30;
fs.mkdirSync(path.join(dir,'compositions'),{recursive:true});
const svg=`<svg id="drawing" viewBox="0 0 1920 1080" width="1920" height="1080" aria-label="An original doodle cat steals a blue fish, hides it and waves" role="img">
<defs><pattern id="dots" width="26" height="26" patternUnits="userSpaceOnUse"><circle cx="5" cy="5" r=".65" fill="#c5c1b9" opacity=".33"/></pattern></defs>
<rect width="1920" height="1080" fill="#f2c96a"/>
<path d="M144 93 L1782 103 L1798 985 L133 973 Z" fill="#d4a94f"/>
<path d="M127 70 L1790 80 L1775 961 L115 950 Z" fill="#fffcf6" stroke="#343936" stroke-width="3"/>
<path d="M127 70 L1790 80 L1775 961 L115 950 Z" fill="url(#dots)"/>
<path d="M204 805 Q873 819 1589 800" fill="none" stroke="#b5b1a7" stroke-width="3" stroke-linecap="round"/>
<g stroke="#b3a99b" stroke-width="3" fill="none" stroke-linecap="round"><path d="M226 150 l32 5 m-18 -16 l13 30"/><path d="M1622 894 q35 -17 54 5 m-64 14 q49 -21 78 2"/><path d="M1495 174 q29 -20 49 6 q-25 28 -54 7"/></g>
<g id="shadow"><ellipse cx="780" cy="812" rx="188" ry="16" fill="#e4e0d7"/></g>
<g id="fish" stroke="#292f33" stroke-width="6" stroke-linejoin="round" stroke-linecap="round">
 <path d="M-85 0 Q-12 -64 83 -2 Q-4 65 -85 0 L-137 -43 L-133 41 Z" fill="${settings.fishColor}"/>
 <path d="M-15 -30 L-27 -57 L23 -36 M-17 30 L-27 52 L23 36" fill="${settings.fishColor}"/>
 <path d="M40 -26 Q19 0 42 27 M-31 -12 q16 13 0 26 M-6 -14 q15 14 0 28" fill="none"/>
 <circle cx="57" cy="-9" r="5" fill="#292f33" stroke="none"/>
</g>
<g id="cat" stroke="#292f33" stroke-width="7" stroke-linecap="round" stroke-linejoin="round">
 <g id="tail"><path d="M-104 113 C-213 113 -251 31 -218 -12 C-189 -50 -160 -15 -181 5 C-203 36 -169 73 -111 72" fill="#fffdf8"/><path d="M-218 -12 q29 8 37 17" fill="none"/></g>
 <path id="body" d="M-98 -96 C-150 -42 -154 101 -116 148 Q-65 182 -1 161 Q73 184 125 146 C156 91 139 -48 93 -98 Z" fill="#fffdf8"/>
 <path d="M-83 84 q-22 25 -18 66 M-66 134 l-1 25 M-48 138 l-1 23 M64 86 q24 24 25 66 M63 137 l1 24 M82 137 l1 24" fill="none"/>
 <path d="M-109 -34 q32 13 25 54 q-14 24 -35 2" fill="#fffdf8"/>
 <g id="head">
  <path d="M-145 -205 L-153 -333 Q-151 -347 -136 -335 L-73 -282 Q0 -306 74 -282 L139 -335 Q154 -348 155 -330 L149 -207 C177 -156 158 -89 91 -65 Q0 -40 -90 -64 C-159 -89 -179 -155 -145 -205 Z" fill="#fffdf8"/>
  <path d="M-133 -305 L-125 -239 L-90 -273 Z M132 -306 L125 -239 L92 -274 Z" fill="#d57b53" stroke="none"/>
  <path d="M-19 -296 l7 39 M13 -297 l-1 36 M43 -290 l-10 36" fill="none" stroke="#d57b53" stroke-width="13"/>
  <ellipse cx="-102" cy="-130" rx="27" ry="13" fill="#edb09b" stroke="none" opacity=".7"/><ellipse cx="101" cy="-130" rx="27" ry="13" fill="#edb09b" stroke="none" opacity=".7"/>
  <g id="open-eyes"><ellipse id="eye-l" cx="-61" cy="-184" rx="29" ry="39" fill="#fff" stroke-width="5"/><ellipse id="eye-r" cx="61" cy="-184" rx="29" ry="39" fill="#fff" stroke-width="5"/><g id="pupils" stroke="none" fill="#292f33"><ellipse id="pupil-l" cx="-55" cy="-181" rx="11" ry="24"/><ellipse id="pupil-r" cx="67" cy="-181" rx="11" ry="24"/><circle cx="-58" cy="-191" r="4" fill="#fff"/><circle cx="64" cy="-191" r="4" fill="#fff"/></g></g>
  <g id="closed-eyes" fill="none"><path d="M-88 -177 q28 21 53 -1 M35 -178 q27 22 53 0"/></g>
  <path d="M-12 -142 Q0 -149 13 -141 L1 -130 Z" fill="#d57b53" stroke-width="4"/>
  <path id="mouth" d="M0 -130 L0 -118 Q-16 -100 -29 -117 M0 -118 Q16 -100 30 -118" fill="none" stroke-width="5"/>
  <path d="M-105 -144 l-65 -12 M-108 -126 l-66 9 M105 -144 l65 -12 M109 -124 l67 10" fill="none" stroke-width="4"/>
  <g id="brows" fill="none" stroke-width="5"><path d="M-89 -238 q25 -13 49 0 M39 -238 q26 -12 50 0"/></g>
 </g>
 <g id="left-wave"><path d="M-103 -13 Q-152 -32 -167 -97 Q-167 -124 -186 -120 Q-211 -110 -192 -74 Q-175 -2 -119 27" fill="#fffdf8"/><path d="M-185 -106 l-7 9 m17 -3 l-7 10" fill="none" stroke-width="4"/></g>
 <g id="right-arm"><path id="arm-outline" d="M91 -23 Q120 8 131 42" fill="none" stroke-width="43"/><path id="arm-fill" d="M91 -23 Q120 8 131 42" fill="none" stroke="#fffdf8" stroke-width="30"/><path id="fingers" d="M126 29 l-8 8 m19 0 l-8 8" fill="none" stroke-width="4"/></g>
</g>
<g id="caught" stroke="#d57b53" stroke-width="8" fill="none" stroke-linecap="round"><path d="M0 -14 l-2 -28 M19 -5 l18 -20 M-20 -5 l-19 -20"/></g>
<g id="sleep-z" fill="#7a8787" font-family="DoodleSans,sans-serif" font-size="42" font-weight="700"><text x="486" y="370">z</text><text x="449" y="325" font-size="30">z</text></g>
<g id="pencil" stroke="#292f33" stroke-width="4" stroke-linejoin="round"><path d="M0 0 L-22 -52 L-21 -268 Q0 -287 21 -268 L22 -52 Z" fill="#e2a562"/><path d="M0 0 L-22 -52 L22 -52 Z" fill="#e9d1ad"/><path d="M0 0 L-7 -17 L7 -17 Z" fill="#292f33"/><path d="M-21 -268 Q0 -287 21 -268 L21 -238 L-21 -238 Z" fill="#cf8276"/><path d="M-8 -58 l0 -177 M8 -58 l0 -177" fill="none" stroke="#a8753b" stroke-width="3"/></g>
</svg>`;
const animation=String.raw`
const clamp=(x)=>Math.max(0,Math.min(1,x));
const smooth=(a,b,t)=>{let u=clamp((t-a)/(b-a));return u*u*(3-2*u)};
const mix=(a,b,u)=>a+(b-a)*u;
const k=(keys,t)=>{if(t<=keys[0][0])return keys[0][1];for(let i=1;i<keys.length;i++){if(t<keys[i][0])return mix(keys[i-1][1],keys[i][1],smooth(keys[i-1][0],keys[i][0],t));}return keys.at(-1)[1]};
const el=id=>document.getElementById(id);
const tr=(id,v)=>el(id).setAttribute('transform',v);
const op=(id,v)=>el(id).setAttribute('opacity',v);
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function renderAt(t){
 let a=t;
 if(t>=14.8&&t<17.6)a=0;
 if(t>=17.6)a=Math.min(9.2,(t-17.6)*1.35+1.3);
 const paperMode=smooth(14.65,15.1,t)*(1-smooth(17.1,17.7,t));
 const breathe=reduced?0:Math.sin(t*2.1)*.9;
 const jitter=reduced?0:(Math.sin(Math.floor(t*10)*1.71)*.48);
 const anticipation=k([[0,0],[2.5,0],[2.9,-7],[3.3,4],[5.5,0],[6.3,0],[6.55,-4],[7,0]],a);
 const x=790+anticipation;
 const y=639+breathe;
 const scale=1.08;
 tr('cat','translate('+x+' '+y+') scale('+scale+')');
 const tilt=k([[0,-7],[1.5,-7],[2.1,5],[2.8,9],[3.3,7],[5.4,-6],[5.8,-10],[6.4,-10],[6.65,0],[8.5,-3]],a);
 tr('head','rotate('+tilt+' 0 -190) translate('+jitter+' 0)');
 tr('tail','rotate('+(paperMode?0:Math.sin(t*2.5)*4)+' -105 98)');
 const eyesOpen=smooth(1.2,1.5,a);
 const smug=smooth(5.35,5.55,a)*(1-smooth(6.2,6.36,a));
 const blink=(1-smooth(8.1,8.18,a))*0+smooth(8.1,8.18,a)*(1-smooth(8.3,8.4,a));
 const lateBlink=t>18?(smooth(21.2,21.28,t)*(1-smooth(21.4,21.5,t))):0;
 const open=eyesOpen*(1-smug)*(1-blink)*(1-lateBlink);
 op('open-eyes',open);op('closed-eyes',1-open);
 op('sleep-z',(1-eyesOpen)*(1-paperMode));
 const look=smooth(1.55,2.2,a)*(1-smooth(6.3,6.55,a));
 tr('pupils','translate('+(look*11)+' '+(look*10)+')');
 const wide=smooth(6.3,6.48,a)*(1-smooth(7.1,7.5,a));
 el('pupil-l').setAttribute('ry',24-wide*12);el('pupil-r').setAttribute('ry',24-wide*12);
 tr('brows','translate(0 '+(-wide*15)+')');
 el('mouth').setAttribute('d',wide>.5?'M-8 -115 Q0 -129 8 -115 Q11 -100 0 -99 Q-11 -100 -8 -115':'M0 -130 L0 -118 Q-16 -100 -29 -117 M0 -118 Q16 -100 30 -118');
 const reach=smooth(3.0,4.25,a);
 const pull=smooth(4.45,5.35,a);
 const hide=smooth(7.1,7.65,a);
 let fx=mix(1320,1050,pull),fy=mix(764,624,pull);
 fx=mix(fx,795,hide);fy=mix(fy,675,hide);
 const angle=3+pull*(-17)+hide*84+(a>4.25&&a<6.2?Math.sin(a*19)*4:0);
 tr('fish','translate('+fx+' '+fy+') rotate('+angle+')');
 const targetX=(fx-61-x)/scale,targetY=(fy-8-y)/scale;
 const px=mix(131,targetX,reach),py=mix(42,targetY,reach);
 const d='M91 -23 Q'+(px*.55+50)+' '+(py*.2-25)+' '+px+' '+py;
 el('arm-outline').setAttribute('d',d);el('arm-fill').setAttribute('d',d);
 el('fingers').setAttribute('d','M'+(px-7)+' '+(py-9)+' l-7 9 m20 -3 l-7 9');
 op('right-arm',1-hide);
 const wave=smooth(8.8,9.3,t)*(1-smooth(14.35,14.7,t));
 const finalWave=smooth(23.5,24.1,t);
 const waving=Math.max(wave,finalWave);
 op('left-wave',waving);
 tr('left-wave','rotate('+(waving*(Math.sin(t*9)*10))+' -105 -10)');
 op('caught',wide);tr('caught','translate('+(x+197)+' '+(y-310)+')');
 tr('shadow','translate('+anticipation+' 0)');
 tr('pencil','translate('+(1570-paperMode*1000)+' '+(885-paperMode*380)+') rotate('+(33-paperMode*65)+')');
 const lineAmount=k([[0,.66],[.9,.66],[1.2,1],[14.8,1],[15.1,.66],[17.1,.66],[17.6,1]],t);
 el('drawing').style.setProperty('--line-amount',lineAmount);
}
window.addEventListener('hf-seek',e=>renderAt(e.detail.time));
const clock={time:0};const tl=gsap.timeline({paused:true});
tl.to(clock,{time:TOTAL,duration:TOTAL,ease:'none',onUpdate:()=>renderAt(clock.time)},0);
renderAt(0);window.__timelines.doodle=tl;
`.replaceAll('TOTAL',String(end));
const fonts=`@font-face{font-family:DoodleSans;src:url('assets/fonts/Inter-400.woff2');font-weight:400}@font-face{font-family:DoodleSans;src:url('assets/fonts/Inter-700.woff2');font-weight:700 900}`;
const overlay=`<div id="greeting" class="clip" data-start="9.1" data-duration="5.6" data-track-index="3" data-beat="Henry greeting"><div class="words" data-hold><p class="greet">Hello my friend</p><p class="welcome">Welcome to<br>Tube U channel</p><p class="henry">I am Henry</p></div></div>
<div id="origin" class="clip" data-start="14.86" data-duration="2.74" data-track-index="3" data-beat="Original doodle"><div class="words" data-hold><p class="eyebrow">BACK TO THE DOODLE</p><h1>Just a<br>few lines</h1></div></div>
<div id="alive" class="clip" data-start="17.6" data-duration="4.8" data-track-index="3" data-beat="A little personality"><div class="words" data-hold><h1>A little<br><span>personality</span></h1></div></div>
<div id="yours" class="clip" data-start="22.4" data-duration="${end-22.4}" data-track-index="3" data-beat="Make your own"><div class="words" data-hold><h1>Let's make<br><span>yours</span></h1><p class="subtitle">A ChatGPT animation tutorial</p></div></div>`;
fs.writeFileSync(path.join(dir,'compositions/doodle.html'),`<template><style>${fonts}#root{position:absolute;inset:0;font-family:DoodleSans,sans-serif;color:#292f33}*{box-sizing:border-box;margin:0}#drawing{position:absolute;inset:0}.clip{position:absolute;inset:0}.words{position:absolute;left:1150px;top:270px;width:560px}.greet{font-size:52px;line-height:1.3;font-weight:700}.welcome{font-size:42px;line-height:1.4;margin-top:30px}.henry{font-size:68px;font-weight:700;letter-spacing:-2px;margin-top:32px}.eyebrow{font-size:29px;color:#6b6154;font-weight:700;margin-bottom:25px}h1{font-size:86px;font-weight:900;line-height:1.1;letter-spacing:-3px}h1 span{color:#aa4d2c}.subtitle{font-size:30px;line-height:1.5;margin-top:32px;max-width:420px}</style><div id="root" data-composition-id="doodle" data-width="1920" data-height="1080">${svg}${overlay}</div><script>${animation}</script></template>`);
const audio=voice.map(v=>`<audio id="voice-${v.id}" class="clip" src="assets/${v.id}.wav" data-start="${v.start}" data-duration="${v.duration}" data-volume="1" data-track-index="2"></audio>`).join('');
const sfx=[['scratch',0.2,0.75],['notice',1.5,.2],['stretch',3.1,.55],['pull',4.5,.35],['caught',6.4,.24],['hide',7.15,.22],['scratch',15.05,.75]];
const sounds=sfx.map(([id,start,dur],i)=>`<audio id="sfx-${i}" class="clip" src="assets/${id}.wav" data-start="${start}" data-duration="${dur}" data-volume=".6" data-track-index="4"></audio>`).join('');
fs.writeFileSync(path.join(dir,'index.html'),`<!doctype html><html lang="en"><head><meta charset="UTF-8"><script src="assets/gsap.min.js"></script><style>*{margin:0;box-sizing:border-box}html,body{width:1920px;height:1080px;overflow:hidden;background:#f2c96a}#root{position:relative;width:1920px;height:1080px}.clip{position:absolute;inset:0}</style></head><body><div id="root" data-composition-id="main" data-start="0" data-duration="${end}" data-width="1920" data-height="1080" data-fps="30"><div id="doodle" class="clip" data-composition-id="doodle" data-composition-src="compositions/doodle.html" data-start="0" data-duration="${end}" data-track-index="1" data-track-kind="graphics" data-width="1920" data-height="1080"></div>${audio}${sounds}</div><script>window.__timelines=window.__timelines||{};window.__timelines.main=gsap.timeline({paused:true});</script></body></html>`);
fs.writeFileSync(path.join(dir,'opening-script.txt'),`涂鸦动画开头试片 v01\n\n0–9.1 秒：小猫偷鱼、被发现、藏鱼。无旁白，动作音效。\n\n${voice.map(v=>`${v.start.toFixed(2)} 秒\n${v.text}\n${v.zh}\n`).join('\n')}\n固定开场白按用户要求保留，未改写为 I'm Henry。\n本机 Microsoft Zira Desktop 为临时试听配音，并非 Henry 本人声音。\n`);
const still=svg.replace('id="fish"','id="fish" transform="translate(1320 764) rotate(3)"').replace('id="cat"','id="cat" transform="translate(790 639) scale(1.08)"').replace('id="head"','id="head" transform="rotate(-7 0 -190)"').replace('id="open-eyes"','id="open-eyes" opacity="0"').replace('id="left-wave"','id="left-wave" opacity="0"').replace('id="caught"','id="caught" opacity="0"').replace('id="pencil"','id="pencil" transform="translate(1570 885) rotate(33)"').replace('<svg id="drawing"','<svg xmlns="http://www.w3.org/2000/svg" id="drawing"');
fs.writeFileSync(path.join(dir,'assets/original-doodle.svg'),still);
fs.writeFileSync(path.join(dir,'cue-plan.json'),JSON.stringify({fps:30,duration:end,voice:voice.map(v=>({...v,timingSource:'Measured per-utterance local SAPI duration; internal anchors estimated'})),shots:[{start:0,end:1.2,action:'Sleeping sketch'},{start:1.2,end:3,action:'Eyes discover fish; anticipate'},{start:3,end:5.35,action:'Reach, make contact, pull fish'},{start:5.35,end:6.4,action:'Smug reaction'},{start:6.4,end:7.1,action:'Caught by viewer'},{start:7.1,end:9.1,action:'Hide fish, innocent blink'},{start:9.1,end:14.7,action:'Wave during exact Henry greeting'},{start:14.86,end:17.6,action:'Return to simple source doodle'},{start:17.6,end:22.4,action:'Replay acting as personality is described'},{start:22.4,end,action:'Invite viewer to make their own'}]},null,2));
console.log({duration:end});

